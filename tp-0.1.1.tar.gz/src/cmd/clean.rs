use crate::utils::set_dirs;

pub fn clean() {
    set_dirs(vec![]);
}

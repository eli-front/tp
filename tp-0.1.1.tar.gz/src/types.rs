pub struct SavedDir {
    pub name: String,
    pub path: String,
}

class Tp < Formula
  desc "Teleport"
  homepage "https://github.com/eli-front/tp"

  url "https://github.com/eli-front/tp/archive/refs/tags/v0.1.1.tar.gz", :using => :curl

  sha256 "c92fe7b5105834b23e2126ee06f7c4afe1bfc02d60c1279cbd80315d35cb7d93"

  def install
    system "cargo", "build", "--release"
    bin.install "target/release/tp"
  end

  test do
    system "#{bin}/tp", "--version"
  end
end


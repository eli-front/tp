class TP < Formula
  desc "Teleport"
  homepage "https://github.com/eli-front/tp"
  url "https://github.com/eli-front/tp/archive/v1.0.0.tar.gz"
  sha256 "<SHA256_SUM>"

  def install
    system "cargo", "install", "--locked", "--root", prefix, "--path", "."
  end

  test do
    system "#{bin}/my_cli_app", "--version"
  end
end

